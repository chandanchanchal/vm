Microsoft Azure WebJobs SDK Samples
-----------------------------------

This repo contains C# samples for the Microsoft Azure WebJobs SDK.

The WebJobs SDK source is public and can be found here: https://github.com/Azure/azure-webjobs-sdk. For more information about WebJobs and the WebJobs SDK see the [WebJobs SDK wiki](https://github.com/Azure/azure-webjobs-sdk/wiki)
