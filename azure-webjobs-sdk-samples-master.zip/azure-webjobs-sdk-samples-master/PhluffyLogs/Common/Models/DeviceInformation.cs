﻿namespace Common.Models
{
    public class DeviceInformation
    {
        public string Manufacturer { get; set; }

        public string Model { get; set; }
    }
}