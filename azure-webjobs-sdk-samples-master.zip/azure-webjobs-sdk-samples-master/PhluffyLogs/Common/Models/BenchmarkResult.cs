﻿namespace Common.Models
{
    public class BenchmarkResult
    {
        public string Benchmark { get; set; }

        public int Data_A { get; set; }
        public int Data_B { get; set; }
        public int Data_C { get; set; }
        public int Data_D { get; set; }
    }
}