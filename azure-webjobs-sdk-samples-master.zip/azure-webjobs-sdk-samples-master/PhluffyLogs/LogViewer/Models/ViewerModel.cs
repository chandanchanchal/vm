﻿using System.Collections.Generic;

namespace LogViewer.Models
{
    public class ViewerModel
    {
        public IEnumerable<string> Benchmarks { get; set; }
    }
}