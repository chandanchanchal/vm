﻿using System.Web.Mvc;

namespace LogViewer.Controllers
{
    public class GeneratorController : Controller
    {
        // GET: Generator
        public ActionResult Index()
        {
            return View();
        }
    }
}