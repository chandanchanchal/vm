﻿using System.Reflection;
[assembly: AssemblyTitle("BlobOperations")]
