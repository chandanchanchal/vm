﻿using System.Reflection;
[assembly: AssemblyTitle("QueueOperations")]
