﻿using System.Reflection;
[assembly: AssemblyTitle("ServiceBus")]
