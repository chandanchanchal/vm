﻿using System.Reflection;
[assembly: AssemblyTitle("TableOperations")]
